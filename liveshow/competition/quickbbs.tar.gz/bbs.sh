#!/bin/bash
#快速部署基于lamp平台的bbs网站
#117-->yum不可用
#118-->部署LAMP失败
#119-->服务启动失败
#120-->论坛部署失败


jindutiao(){
    line='########################'
    len=`echo ${line} | wc -L`
    i=0
    while :
    do
        if [ $i -eq 0 ];then
            left=""
        else
            left=`echo ${line} | cut -b 1-$i`
        fi
        j=`expr $i + 1`
        if [ $i -eq ${len} ];then
            right=""
        else
            right=`echo ${line} | cut -b $j-${len}`
        fi
        echo -ne "${left}@${right}""\r"
        sleep 0.2
        let i++
        if [ $i -gt ${len} ];then
            i=0
        fi
    done
}

check_yum(){
	yum clean all &> /dev/null
	p_num=`yum repolist | tail -1 | awk '{print $2}'`
	if [ ${p_num} != 0 ];then
		echo "yum可用"
	else
		echo "yum不可用，请配置yum源"
		exit 117
	fi
}

install_lamp(){
	clear
	jindutiao &
	disown $!
	check_yum
	kill -9 $!
	jindutiao &
	disown $!
	yum -y install httpd php php-mysql mariadb mariadb-server &> /dev/null
	res=$?
	kill -9 $!
	if [ ${res} -eq 0 ];then
		echo "LAMP部署成功"
		jindutiao &
		disown $!
		systemctl start httpd.service && systemctl enable httpd.service &> /dev/null
		res1=$?
		systemctl start mariadb.service && systemctl enable mariadb.service &>/dev/null
		res2=$?
		kill -9 $!
		if [ ${res1} -eq 0 -a ${res2} -eq 0 ];then
			echo "httpd和mariadb服务启动成功"
		else
			echo "httpd或mariadb服务启动失败，请检查"
			exit 119
		fi
	else
		echo "LAMP部署失败，请检查"
		exit 118
	fi
}

install_bbs(){
	jindutiao &
	disown $!
	mysqladmin -uroot password 123456
	tar -xf bbsdb.tar.gz
	mv bbsdb /var/lib/mysql
	chmod 700 /var/lib/mysql/bbsdb
	chown mysql:mysql -R /var/lib/mysql/bbsdb
	res1=$?
	tar -xf bbs.tar.gz
	mv bbs /var/www/html/
	chown apache:apache -R /var/www/html/bbs
	res2=$?
	kill -9 $!
	if [ ${res1} -eq 0 -a ${res2} -eq 0 ];then
		echo "论坛部署成功"
	else
		echo "论坛部署失败"
		exit 120 
	fi
}

install_lamp
install_bbs
